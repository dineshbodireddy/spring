package com.hcl.controller;

import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.dto.EmployeeRequestDto;
import com.hcl.entity.Employee;
import com.hcl.exception.UserDefinedException;
import com.hcl.service.IEmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;

	@PostMapping("/employees")
	public ResponseEntity<String> saveEmployeeDetails(@Valid @RequestBody EmployeeRequestDto employeeRequestDto) {
		String response = employeeService.saveEmployeeDetails(employeeRequestDto);
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	@PutMapping("/employees")
	public ResponseEntity<String> updateEmployeeDetails(@Valid @RequestBody EmployeeRequestDto employeeRequestDto)
			throws UserDefinedException {
		String response = employeeService.updateEmployeeDetails(employeeRequestDto);
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getEmployeeDetails() {
		return new ResponseEntity<List<Employee>>(employeeService.getEmployeeDetails(), HttpStatus.OK);
	}

	@DeleteMapping("/employees/{id}")
	public ResponseEntity<String> deleteEmployeeDetails(@PathVariable int id) throws UserDefinedException {
		boolean isDeleted = employeeService.deleteEmployeeDetails(id);
		if (isDeleted) {
			return new ResponseEntity<String>("Employee deleted successfully", HttpStatus.OK);
		}
		return new ResponseEntity<String>("Employee not deleted successfully ", HttpStatus.NOT_FOUND);
	}
}
