package com.hcl.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class EmployeeRequestDto {
	private int id;
	
	@NotNull(message="Name cannot be null")
	@Size(min=3,max=60,message="Name should be between 3 to 60 charachters")
	private String employeeName;
	
	@NotNull(message="Designation cannot be null")
	@Size(min=3,max=20,message="Designation should be between 3 to 20 charachters")
	private String designation;
	
	@NotNull(message="Location cannot be null")
	@Size(min=3,max=15,message="Location should be between 3 to 15 charachters")
	private String location;
	
	@NotNull(message="projectName cannot be null")
	@Size(min=3,max=30,message="projectName should be between 3 to 30 charachters")
	private String projectName;
	

	public EmployeeRequestDto(int id,
			@NotNull(message = "Name cannot be null") @Size(min = 3, max = 60, message = "Name should be between 3 to 60 charachters") String employeeName,
			@NotNull(message = "Designation cannot be null") @Size(min = 3, max = 20, message = "Designation should be between 3 to 20 charachters") String designation,
			@NotNull(message = "Location cannot be null") @Size(min = 3, max = 15, message = "Location should be between 3 to 15 charachters") String location,
			@NotNull(message = "projectName cannot be null") @Size(min = 3, max = 30, message = "projectName should be between 3 to 30 charachters") String projectName) {
		super();
		this.id = id;
		this.employeeName = employeeName;
		this.designation = designation;
		this.location = location;
		this.projectName = projectName;
	}
	

	public EmployeeRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	@Override
	public String toString() {
		return "EmployeeRequestDto [id=" + id + ", employeeName=" + employeeName + ", designation=" + designation
				+ ", location=" + location + ", projectName=" + projectName + "]";
	}
	
}
