package com.hcl.repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.entity.Employee;

public interface IEmployeeRepository extends JpaRepository<Employee, Integer>{

}
