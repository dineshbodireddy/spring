package com.hcl.service;

import java.util.List;

import com.hcl.dto.EmployeeRequestDto;
import com.hcl.entity.Employee;
import com.hcl.exception.UserDefinedException;

public interface IEmployeeService {
	String saveEmployeeDetails(EmployeeRequestDto employeeRequestDto);

	List<Employee> getEmployeeDetails();

	String updateEmployeeDetails(EmployeeRequestDto employeeRequestDto) throws UserDefinedException;

	boolean deleteEmployeeDetails(int id) throws UserDefinedException;
}
