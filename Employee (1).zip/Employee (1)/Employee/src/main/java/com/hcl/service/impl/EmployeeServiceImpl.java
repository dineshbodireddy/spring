package com.hcl.service.impl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import com.hcl.dto.EmployeeRequestDto;
import com.hcl.entity.Employee;
import com.hcl.exception.UserDefinedException;
import com.hcl.repositry.IEmployeeRepository;
import com.hcl.service.IEmployeeService;

@Service
public class EmployeeServiceImpl implements IEmployeeService

{
	@Autowired
	IEmployeeRepository employeeRepository;

	@Override
	public String saveEmployeeDetails(EmployeeRequestDto employeeRequestDto) {
		Employee employee = new Employee();
		BeanUtils.copyProperties(employeeRequestDto, employee);
		Employee employeePersistence = employeeRepository.save(employee);
		if (ObjectUtils.isEmpty(employeePersistence))
		{
			return "Employee not saved";
		}
		return "Employee registered successfully";

	}

	@Override
	public List<Employee> getEmployeeDetails() {
		return employeeRepository.findAll();
	}

	@Override
	public String updateEmployeeDetails(EmployeeRequestDto employeeRequestDto) throws UserDefinedException {
		Employee employee = new Employee();
		BeanUtils.copyProperties(employeeRequestDto, employee);
		if (employeeRepository.findById(employee.getId()).isPresent()) {
			employeeRepository.save(employee);
			return "Employee Updated Successfully";
			
		} else {
			throw new UserDefinedException("Employee Id dosen't exsists");
		}
	}

	@Override
	public boolean deleteEmployeeDetails(int id) throws UserDefinedException {
		if (employeeRepository.findById(id).isPresent()) {
			employeeRepository.deleteById(id);
			return true;
		} else {
			throw new UserDefinedException("Employee Id dosen't exsists");
		}
	}

}
