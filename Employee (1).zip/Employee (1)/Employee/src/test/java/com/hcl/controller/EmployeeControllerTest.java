package com.hcl.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.hcl.dto.EmployeeRequestDto;
import com.hcl.entity.Employee;
import com.hcl.exception.UserDefinedException;
import com.hcl.service.IEmployeeService;

@ExtendWith(MockitoExtension.class)
public class EmployeeControllerTest {

	@Mock
	IEmployeeService employeeService;

	@InjectMocks
	EmployeeController employeeController;

	static EmployeeRequestDto employeeRequestDto;
	static EmployeeRequestDto employeeRequestDto1;

	@BeforeAll
	public static void setUp() {
		employeeRequestDto = new EmployeeRequestDto();
		employeeRequestDto.setId(100);
		employeeRequestDto.setEmployeeName("Tejaswi");
		employeeRequestDto.setDesignation("Software");
		employeeRequestDto.setLocation("bangalore");
		employeeRequestDto.setProjectName("DBS");
		
		employeeRequestDto1=new EmployeeRequestDto();
		employeeRequestDto1.setId(100);
		employeeRequestDto1.setEmployeeName("Jyothi");
		employeeRequestDto1.setDesignation("ASE");
		employeeRequestDto1.setLocation("Hyderabad");
		employeeRequestDto1.setProjectName("DBS");
		
	}

	@Test
	@DisplayName("Employee Registration:Positive Scenario")
	public void employeeRegistrationTest1() {
		// given or context
		when(employeeService.saveEmployeeDetails(employeeRequestDto)).thenReturn("success");

		// when or event
		ResponseEntity<String> result = employeeController.saveEmployeeDetails(employeeRequestDto);

		// then or outcome
		verify(employeeService).saveEmployeeDetails(employeeRequestDto);
		assertEquals("success", result.getBody());
		assertEquals(HttpStatus.OK, result.getStatusCode());
	}

	@Test
	@DisplayName("Employee Registration:Negative Scenario")
	public void employeeRegistrationTest2() {
		// given or context
		when(employeeService.saveEmployeeDetails(employeeRequestDto)).thenReturn("failed");

		// when or event
		ResponseEntity<String> result = employeeController.saveEmployeeDetails(employeeRequestDto);

		// then or outcome
		verify(employeeService).saveEmployeeDetails(employeeRequestDto);
		assertEquals("failed", result.getBody());
		assertEquals(HttpStatus.OK, result.getStatusCode());
	}

	@Test
	@DisplayName("Deleting employee test:Positive Scenario")
	public void deleteEmployeeTest1() throws UserDefinedException {
		int id = 103;
		// given or context
		when(employeeService.deleteEmployeeDetails(id)).thenReturn(true);
		// when or event
		ResponseEntity<String> result = employeeController.deleteEmployeeDetails(id);
		// then or outcome
		verify(employeeService).deleteEmployeeDetails(id);
		assertEquals("Employee deleted successfully", result.getBody());
		assertEquals(HttpStatus.OK, result.getStatusCode());
	}

	@Test
	@DisplayName("Deleting employee test:Negative Scenario")
	public void deleteEmployeeTest2() throws UserDefinedException {
		int id = 133;
		// given or context
		when(employeeService.deleteEmployeeDetails(id)).thenReturn(false);
		// when or event
		ResponseEntity<String> result = employeeController.deleteEmployeeDetails(id);
		// then or outcome
		verify(employeeService).deleteEmployeeDetails(id);
		assertEquals("Employee not deleted successfully ", result.getBody());
		assertEquals(HttpStatus.NOT_FOUND, result.getStatusCode());
	}

	@Test
	@DisplayName("All  employee details:Positive Scenario")
	public void getEmployeeDetailsTest1() {
		List<Employee> list = new ArrayList<Employee>();
		Employee e = new Employee(100, "Tejaswi", "Software", "bangalore", "DBS");
		Employee e1 = new Employee(101, "Te", "Software", "bangalore", "DBS");
		list.add(e);
		list.add(e1);
		when(employeeService.getEmployeeDetails()).thenReturn(list);
		ResponseEntity<List<Employee>> result = employeeController.getEmployeeDetails();
		verify(employeeService).getEmployeeDetails();
		assertEquals(list, result.getBody());
		assertEquals(HttpStatus.OK, result.getStatusCode());
	}

	@Test
	@DisplayName("update Employee details:Positive Scenario")
	public void updateEmployeeDetailsTest1() throws UserDefinedException {
		
		
		when(employeeService.updateEmployeeDetails(employeeRequestDto1)).thenReturn("updated");
		// when or event
				ResponseEntity<String> result = employeeController.updateEmployeeDetails(employeeRequestDto1);

				// then or outcome
				verify(employeeService).updateEmployeeDetails(employeeRequestDto1);
				assertEquals("updated", result.getBody());
				assertEquals(HttpStatus.OK, result.getStatusCode());
		
	}
	
	@Test
	@DisplayName("update Employee details:Negative Scenario")
	public void updateEmployeeDetailsTest2() throws UserDefinedException {
		
		
		when(employeeService.updateEmployeeDetails(employeeRequestDto1)).thenReturn("not updated");
		// when or event
				ResponseEntity<String> result = employeeController.updateEmployeeDetails(employeeRequestDto1);

				// then or outcome
				verify(employeeService).updateEmployeeDetails(employeeRequestDto1);
				assertEquals("not updated", result.getBody());
				assertEquals(HttpStatus.OK, result.getStatusCode());
		
	}

}
